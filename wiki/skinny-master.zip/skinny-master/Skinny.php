<?php
/**
 * Skinny
 * Simple tools to help advanced skinning techniques.
 * to predefined areas in your skin.
 * Intended for MediaWiki Skin designers.
 * By Andru Vallance - andru@tinymighty.com
 *
 * License: GPL - http://www.gnu.org/copyleft/gpl.html
 *
 */

// Haven't seen how this gets migrated to the extension.json way of doing things yet...
$wgExtensionMessagesFiles['ExampleExtensionMagic'] = __DIR__ . '/ExampleExtension.i18n.magic.php';
