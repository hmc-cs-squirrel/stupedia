Skinny
======

Skinny is a set of tools to make skinning MediaWiki more bearable.
